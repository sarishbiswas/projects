package com.cognizant.spring_demo.reftypes;

public class Scores {
	private Double mats;
	private Double physics;
	private Double chemistry;
	public Double getMats() {
		return mats;
	}
	public void setMats(Double mats) {
		this.mats = mats;
	}
	public Double getPhysics() {
		return physics;
	}
	public void setPhysics(Double physics) {
		this.physics = physics;
	}
	public Double getChemistry() {
		return chemistry;
	}
	public void setChemistry(Double chemistry) {
		this.chemistry = chemistry;
	}
	
	
}
