package com.cognizant.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import com.cognizant.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public double getMaxSal(String dept) {
		// TODO Auto-generated method stub
		Connection con;
		PreparedStatement p;
		ResultSet rs;
		try {
			con=ConnectionHandler.makeConnection();
			String sql = "Select max(salary) from employee";
			p=con.prepareStatement(sql);
			rs=p.executeQuery();
			if(rs.next()){
				return rs.getDouble(1);
			}
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		return 0;
	}

	@Override
	public boolean insert(Employee e)  {
		// TODO Auto-generated method stub
		Connection con;
		try {
			con = ConnectionHandler.makeConnection();
			String sql="insert into employee values(?,?,?,?,?,?)";
			PreparedStatement p=con.prepareStatement(sql);
			p.setInt(1, e.getId());
			p.setString(2, e.getName());
			p.setDate(3, new Date(e.getDoj().getTime()));
			p.setDouble(4, e.getSalary());
			p.setDouble(5, e.getComm());
			p.setString(6, e.getDept());
			p.executeUpdate();
		} catch (ClassNotFoundException | IOException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return true;

	}

	@Override
	public boolean update(Employee e) {
		// TODO Auto-generated method stub
		Connection con;
		PreparedStatement p;
		boolean flag = false;
		try {
			con=ConnectionHandler.makeConnection();
			String sql = "UPDATE employee SET name=?,doj=?,salary=?,comm=?,dept=? WHERE id=?";
			p=con.prepareStatement(sql);
			p.setString(1, e.getName());
			p.setDate(2,new Date(e.getDoj().getTime()));
			p.setDouble(3, e.getSalary());
			p.setDouble(4, e.getComm());
			p.setString(5, e.getDept());
			p.setInt(6,e.getId());
			p.executeUpdate();
			flag=true;
		} catch (ClassNotFoundException | IOException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean delete(Employee e) {
		// TODO Auto-generated method stub
		Connection con;
		PreparedStatement p;
		boolean flag = false;
		try {
			con=ConnectionHandler.makeConnection();
			String sql = "delete from employee where id =?";
			p=con.prepareStatement(sql);
			p.setInt(1, e.getId());
			p.executeUpdate();
			flag = true;
		} catch (ClassNotFoundException | IOException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		Connection con;
		List<Employee> list= new ArrayList<>();
		try {
			con = ConnectionHandler.makeConnection();
			String sql="Select * from employee";
			ResultSet rs = con.createStatement().executeQuery(sql);
			while(rs.next()){
				Employee e = new Employee(rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getDouble(4),rs.getDouble(5),rs.getString(6));
				list.add(e);
			}
			rs.close();
		} catch (ClassNotFoundException | IOException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return list;
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		Connection con;
		Employee emp=null;
		ResultSet rs;
		try {
			con = ConnectionHandler.makeConnection();
			String sql="Select * from employee where id=?";
			PreparedStatement p=con.prepareStatement(sql);
			p.setInt(1, id);
			 rs = p.executeQuery();
			System.out.println("This is good");
			while(rs.next())
				emp = new Employee(rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getDouble(4),rs.getDouble(5),rs.getString(6));
			}catch (ClassNotFoundException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		return emp;
	}

	@Override
	public Employee getByMaxSal() {
		// TODO Auto-generated method stub
		Connection con;
		PreparedStatement p;
		Employee emp=null;
		ResultSet rs;
		try {
			con= ConnectionHandler.makeConnection();
			String sql= "select * from employee where salary=(select max(salary) from employee)";
			p=con.prepareStatement(sql);
			rs=p.executeQuery();
			while(rs.next())
				emp = new Employee(rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getDouble(4),rs.getDouble(5),rs.getString(6));
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}

}
