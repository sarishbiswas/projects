package com.cognizant.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionHandler {
	public static Connection makeConnection() throws FileNotFoundException, IOException, ClassNotFoundException, SQLException{
		Connection con=null;
		Properties prop=null;
		
		prop=new Properties();
		prop.load(new FileInputStream("db.properties"));
		Class.forName(prop.getProperty("driver"));
		con = DriverManager.getConnection(prop.getProperty("connection-url"),prop.getProperty("user"),prop.getProperty("password"));
		System.out.println("Connection Established");
		return con;
	}
}
