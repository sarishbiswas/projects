package com.cognizant.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cognizant.model.Employee;

public interface EmployeeDao {
	public double getMaxSal(String dept);
	public boolean insert(Employee e) throws FileNotFoundException, ClassNotFoundException, IOException, SQLException ;
	public boolean update(Employee e);
	public boolean delete(Employee e);
	public List<Employee> getAll();
	public Employee getById(int id);
	public Employee getByMaxSal();

}
