package com.cognizant.service;

import java.text.ParseException;
import java.util.List;

import com.cognizant.dao.EmployeeDaoImpl;
import com.cognizant.model.Employee;
import com.cognizant.util.DateUtil;

public class EmployeeService {
	public static void main(String[] args) throws ParseException {
		Employee e=new Employee(5,"Anuj",DateUtil.stringToDate("56/11/2019"),10000.0,1000.0,"IT");
		EmployeeDaoImpl obj = new EmployeeDaoImpl();
		System.out.println(obj.insert(e));
		List<Employee> emp = obj.getAll();
		for (Employee employee : emp) {
			System.out.println(employee);
		}
		Employee e1=new Employee(1,"Anuj",DateUtil.stringToDate("14/11/2019"),20000.0,500.0,"CSE");
		System.out.println(obj.getById(1));
		System.out.println(obj.getByMaxSal());
		System.out.println(obj.getMaxSal("IT"));
		System.out.println(obj.update(e1));
		Employee e2=new Employee(2,"Anuj",DateUtil.stringToDate("14/11/2019"),20000.0,500.0,"CSE");
		System.out.println(obj.delete(e2));
		System.out.println(obj.getById(1));
		System.out.println(obj.getByMaxSal());
	}
}
