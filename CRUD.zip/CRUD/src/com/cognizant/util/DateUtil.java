package com.cognizant.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static Date stringToDate(String s) throws ParseException{
		Date d= new SimpleDateFormat("dd/mm/yyyy").parse(s);
		return d;
	}
}
