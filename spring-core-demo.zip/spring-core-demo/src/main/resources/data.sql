insert into employees(id,name,salary) values (100,"Nayan",50000);
insert into employees(id,name,salary) values (200,"Ayan",60000);
