use spring_db;
create table employee(id int(10) not null default '0', name varchar(100) default null,salary double default null,primary key (id));