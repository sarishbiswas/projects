package com.cognizant.jdbc.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.jdbc.dao.EmployeeDao;
import com.cognizant.jdbc.dao.EmployeeDaoImpl;
import com.cognizant.jdbc.model.Employee;

public class EmployeeService {

	public static void main(String[] args) {
	
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		Employee emp=new Employee();
    	System.out.println(emp.toString());
    	EmployeeDao dao=(EmployeeDao)context.getBean("edao");  
        
        emp.setId(100);
        emp.setName("Nayan");
        emp.setSalary(100.90);
        emp.setDepartment("CSE");
        System.out.println(dao.insert(emp));  
        List<Employee> list = dao.getAll();    

        for(Employee e : list)  

        {  

        System.out.println(e); 

         }    
	
	
	}

}
