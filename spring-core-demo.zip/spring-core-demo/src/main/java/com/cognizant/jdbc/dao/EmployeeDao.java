package com.cognizant.jdbc.dao;

import java.util.List;

import com.cognizant.jdbc.model.Employee;

public interface EmployeeDao {

String insert(Employee emp);
String update(Employee emp);
String delete(Employee emp);
List<Employee> getAll();



}
