package com.cognizant.jdbc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.cognizant.jdbc.model.Employee;
import com.mysql.jdbc.ResultSet;

public class EmployeeDaoImpl implements EmployeeDao{

	
	private JdbcTemplate jdbcTemplate;
	

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public String insert(Employee emp) {
		int update=this.jdbcTemplate.update(
		        "insert into employee(id,name,salary,department) values (?,?,?,?)",
		        emp.getId(),emp.getName(),emp.getSalary(),emp.getDepartment());
	if(update>0){
		return("Success");
	}
	else{
		
	return("Fail");	
		
	}
	
}

	public String update(Employee emp) {
		// TODO Auto-generated method stub
		int update=this.jdbcTemplate.update(
		        "update employee set salary = ? where id=? ",
		        emp.getSalary(),emp.getId());
	if(update>0){
		return("Success");
	}
	else{
		
	return("Fail");	
		
	}
	}

	public String delete(Employee emp) {
		// TODO Auto-generated method stub
		int update=this.jdbcTemplate.update(
		        "delete * from employee where id=?",
		        emp.getId());
	if(update>0){
		return("Success");
	}
	else{
		
	return("Fail");	
		
	}
	}
	public List<Employee> getAll() {

		 RowMapper<Employee> mapper = new RowMapper<Employee>() {



		  public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {

		  Employee emp=new Employee();



		   emp.setId(rs.getInt(1));

		   emp.setName(rs.getString(2));

		   emp.setSalary(rs.getDouble(3));

		   emp.setDepartment(rs.getString(4));



		  return emp;

		  }

		public Employee mapRow(java.sql.ResultSet rs, int rowNum) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}



		 };

		 String sql="select * from Employee";

		 return jdbcTemplate.query(sql, mapper);

		 }

		   

}
