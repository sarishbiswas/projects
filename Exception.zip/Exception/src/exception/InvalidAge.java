package exception;

public class InvalidAge {

}
