package exception;

public class Student {

}
