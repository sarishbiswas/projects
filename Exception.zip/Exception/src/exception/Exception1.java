package exception;

public class Exception1 {
	public static void main(String []args){
		System.out.println("Stsrt of exception");
		int a=0,b=0,c=0;
		try{
			a=Integer.parseInt(args[0]);
			b=Integer.parseInt(args[1]);
			c=b/a;
			System.out.println(c);
		}catch(ArithmeticException e){
			//handle the exception
			System.out.println(e);
		}
		catch(NumberFormatException e){
			System.out.println(e);
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
		}
		catch(Exception e){
			System.out.println(e);
		}
		System.out.println("End of main");
	}
}
