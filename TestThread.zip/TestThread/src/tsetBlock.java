public class tsetBlock extends Thread {
	private static int id;
	public tsetBlock(int id){
		tsetBlock.id=id;
	}
	public void run(){
		System.out.println("Thread called "+tsetBlock.id);
	}
}
