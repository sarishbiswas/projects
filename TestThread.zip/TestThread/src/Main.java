
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		tsetBlock t=null;
		for(int i=0;i<5;i++){
			t=new tsetBlock(i);
			t.start();
			try {
				t.join();
				System.out.println("thread ended "+i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
