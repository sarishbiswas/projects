package com.cognizant.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.dao.EmployeeDao;
import com.cognizant.dao.EmployeeDaoImpl;
import com.cognizant.model.Employee;

/**
 * Servlet implementation class EmployeeController
 */
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmployeeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	EmployeeDao employee = new EmployeeDaoImpl();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());

		// Read the Request parameter
		String action = request.getParameter("action");

		if (action.equals("insert")) {
			insert(request, response);
		} else if (action.equals("update")) {
			update(request, response);
		} else if (action.equals("delete")) {
			Delete(request, response);
		} else if (action.equals("getAll")) {
			getAll(request, response);
		} else {

		}

	}

	private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		double salary = Double.parseDouble(request.getParameter("salary"));
		RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
		String res=employee.update(new Employee(id,name,salary));
		if(res.equals("SUCCESS"))
			request.setAttribute("msg", "Record Updated Successfully");
		else
			request.setAttribute("msg", "Record not Updated Successfully");
		rd.forward(request, response);

	}

	private void Delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		RequestDispatcher rd = request.getRequestDispatcher("delete.jsp");
		String res=employee.delete(new Employee(id));
		if(res.equals("SUCCESS"))
			request.setAttribute("msg", "Record Deleted Successfully");
		else
			request.setAttribute("msg", "Record not Deleted Successfully");
		rd.forward(request, response);
	}

	private void getAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Invoke Dao
		List<Employee> list = employee.getAll();

		// Dispatch the request to show.jsp
		RequestDispatcher rd = request.getRequestDispatcher("show.jsp");
		
		//Add data/attribute to the request
		request.setAttribute("list", list);
		
		// Forward the request
		rd.forward(request, response);
	}

	private void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		double salary = Double.parseDouble(request.getParameter("salary"));
		RequestDispatcher rd = request.getRequestDispatcher("insert.jsp");
		String res=employee.create(new Employee(id,name,salary));
		System.out.println(res);
		if(res.equals("SUCCESS"))
			request.setAttribute("msg", "Record Inseted Successfully");
		else
			request.setAttribute("msg", "Record not Inseted Successfully");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
