package com.dao;

import java.io.BufferedReader;
import com.model.Package;
import com.util.ConnectionHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PackageDaoImplTest {
	public static void main(String[] args) {
		PackageDaoImpl test = new PackageDaoImpl();
		ArrayList<Package> list = test.raedFileData();
		ConnectionHandler con = new ConnectionHandler();
		test.insert(con.handelConnection(), list);
	}

}
