package com.dao;

import java.io.BufferedReader;
import com.model.Package;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.model.Package;

public class PackageDaoImpl implements PackageDao {

	public ArrayList<Package> raedFileData() {
		FileReader in = null;
		ArrayList<Package> list = new ArrayList<Package>();
		try {
			in = new FileReader("C:/Users/851461/Desktop/package.txt");
			BufferedReader br = new BufferedReader(in);
			String line = null;
			while ((line = br.readLine()) != null) {
				String[] st = line.split(",");
				double d = Double.parseDouble(st[3]);
				int a = Integer.parseInt(st[4]);
				double pc = 0.0;
				if (a <= 5) {
					pc = d;
				} else if (a <= 8) {
					pc = d - (d * 0.03);
				} else if (a <= 10) {
					pc = d - (d * 0.05);
				} else {
					pc = d - (d * 0.07);
				}
				try {
					Package ex = new Package(st[0], st[1], st[2], d, a, pc);
					list.add(ex);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.getMessage();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public void insert(Connection con, ArrayList<Package> pi) {
		// TODO Auto-generated method stub
		String sql = "insert into package values(?,?,?,?,?,?)";

		boolean result = false;
		int count = 0;

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			for (Package p : pi) {
				ps.setString(1, p.getPackageId());
				ps.setString(2, p.getSource());
				ps.setString(3, p.getDestination());
				ps.setDouble(4, p.getBasicFare());
				ps.setInt(5, p.getNoOfDays());
				ps.setDouble(6, p.getPackageCost());
				ps.addBatch();
				count++;
				// execute every 100 rows or less
			}
			ps.executeBatch();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
