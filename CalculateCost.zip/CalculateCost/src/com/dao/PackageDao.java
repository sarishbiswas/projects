package com.dao;

import java.sql.Connection;
import java.util.ArrayList;

import com.model.Package;
public interface PackageDao {
	public void insert(Connection con,ArrayList<Package> p);
}
