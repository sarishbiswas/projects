package com.util;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionHandler {
	private static Connection con=null;
	private static Properties pops=null;
	
	
	public Connection handelConnection(){
		FileInputStream fis = null;
		try {
			pops=new Properties();
			fis = new FileInputStream("C:/Users/851461/workspace/CalculateCost/db.properties");
			pops.load(fis);
			
			Class.forName(pops.getProperty("DB_DRIVER_CLASS"));
			this.con =DriverManager.getConnection(pops.getProperty("db_url"),pops.getProperty("username") , pops.getProperty("password"));
			System.out.println("Connection Established");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	
}
